const t={"Internet Usage":"网络用量",select_location:"选择位置",select_location_hint:"点击旗帜随机切换代理",select_location_empty:"暂无可用的旗帜代理"};export{t as data};
