const t={"Internet Usage":"網路用量",select_location:"選擇位置",select_location_hint:"點擊旗幟隨機切換代理",select_location_empty:"沒有可用的旗幟代理"};export{t as data};
